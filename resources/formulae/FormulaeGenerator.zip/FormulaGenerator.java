import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.IntStream;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.openscience.cdk.Atom;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IChemObjectBuilder;
import org.openscience.cdk.interfaces.IIsotope;
import org.openscience.cdk.interfaces.IMolecularFormula;
import org.openscience.cdk.qsar.descriptors.molecular.HBondAcceptorCountDescriptor;
import org.openscience.cdk.qsar.descriptors.molecular.HBondDonorCountDescriptor;
import org.openscience.cdk.qsar.descriptors.molecular.MannholdLogPDescriptor;
import org.openscience.cdk.qsar.descriptors.molecular.RuleOfFiveDescriptor;
import org.openscience.cdk.tools.manipulator.MolecularFormulaManipulator;

public class FormulaGenerator {
	public static FileWriter outputFile;
    public static int isotopes;
    public static int heavyAtomsLimit;
    public static boolean verbose = false;
    public static String output;
    public static int totalValue; // Total number of hydrogens.
    public Map<String, Integer> valences;
    public static IChemObjectBuilder builder = DefaultChemObjectBuilder.getInstance();
    {
        // The atom valences from CDK.
        valences = new HashMap<>();

        valences.put("C", 4);
        valences.put("N", 3);
        valences.put("O", 2);
        valences.put("S", 2);
        valences.put("P", 3);
        valences.put("F", 1);
        valences.put("I", 1);
        valences.put("Cl", 1);
        valences.put("Br", 1);
        valences.put("H", 1);
    }
    
    /**
     * Checking whether a molecular formula can represent a graph or not.
     *
     * <p>For a graph with n nodes, the sum of all its node degrees should be equal or bigger than
     * 2*(n-1). Thus, the minimum number of nodes.
     *
     * @param formula String molecular formula
     * @return boolean
     */
    public static boolean canBuildIsomer(int[] array) {
    	int[] valences= new int[8];
        valences[0]=4; //C
        valences[1]=3; //N
        valences[2]=2; //O
        valences[3]=2; //S
        valences[4]=1; //F
        valences[5]=1; //Cl
        valences[6]=1; //Br
        valences[7]=1; //I
        int localSize = 0;
        int sum = 0;
        for(int i=0;i<array.length;i++) {
            localSize += array[i];
            sum += (valences[i] * array[i]);
        }
        return sum % 2 == 0 && sum >= 2 * (localSize - 1);
    }
    
    /**
     * Lipinski's rules
     */
    
    public static boolean RuleOfFiveDescriptor(String formula) {
    	boolean check=true;
    	IMolecularFormula iFormula= MolecularFormulaManipulator.getMolecularFormula(formula, builder);
    	IAtomContainer ac= buildContainer(iFormula);
    	RuleOfFiveDescriptor m= new RuleOfFiveDescriptor();
    	m.calculate(ac);
    	return check;
    }
    
    public static boolean lipinskiCheck(String formula) {
    	boolean check=true;
    	IMolecularFormula iFormula= MolecularFormulaManipulator.getMolecularFormula(formula, builder);
    	IAtomContainer ac= buildContainer(iFormula);
    	if(!logPCheck(ac) || !hBondAcceptor(ac) || !hBondDonor(ac) || !molecularMassCheck(iFormula)) {
    		check=false;
    	}
    	return check;
    }
    
    /**
     * Build atomContainer from IMolecularFormula
     * 
     * @param formula IMolecularFormula formula
     * @return
     */
    public static IAtomContainer buildContainer(IMolecularFormula formula) {
    	int count=0;
    	String symbol=null;
    	IAtomContainer atomContainer = builder.newAtomContainer();
    	for(IIsotope iso: formula.isotopes()) {
    		symbol=iso.getSymbol();
    		count=formula.getIsotopeCount(iso);
    		for(int i=0;i<count;i++) {
    			atomContainer.addAtom(new Atom(symbol));
    		}
    	}
    	return atomContainer;
    }
    
    /**
     * Lipinski' rule for logP
     * 
     * @param formula IMolecularFormula formula
     * @return
     */
    
    public static boolean logPCheck(IAtomContainer atomContainer) {
    	boolean check=true;
    	MannholdLogPDescriptor n= new MannholdLogPDescriptor();
    	Double result= Double.valueOf(n.calculate(atomContainer).getValue().toString());
    	if(result>5) check=false;
    	return check;
    }
    
    /**
     * Lipinski' rule for hydrogen bond acceptor
     * 
     * @param formula IMolecularFormula formula
     * @return
     */
    
    public static boolean hBondAcceptor(IAtomContainer atomContainer) {
    	boolean check=true;
    	HBondAcceptorCountDescriptor m= new HBondAcceptorCountDescriptor();
    	Double result= Double.valueOf(m.calculate(atomContainer).getValue().toString());
    	if(result>10) check=false;
    	return check;
    }
    
    /**
     * Lipinski' rule for hydrogen bond donor
     * 
     * @param formula IMolecularFormula formula
     * @return
     */
    
    public static boolean hBondDonor(IAtomContainer atomContainer) {
    	boolean check=true;
    	HBondDonorCountDescriptor m= new HBondDonorCountDescriptor();
    	Double result= Double.valueOf(m.calculate(atomContainer).getValue().toString());
    	if(result>5) check=false;
    	return check;
    }
    
    /**
     * Lipinski' rule for molecular mass
     * 
     * @param formula IMolecularFormula formula
     * @return
     */
    
    public static boolean molecularMassCheck(IMolecularFormula formula) {
    	boolean check=true;
    	double mass= MolecularFormulaManipulator.getMass(formula);
    	if(mass>500) check=false;
    	return check;
    }
    
    public static boolean canBuildIsomer(int[] array, int hydrogens) {
    	int[] valences= new int[8];
        valences[0]=4; //C
        valences[1]=3; //N
        valences[2]=2; //O
        valences[3]=2; //S
        valences[4]=1; //F
        valences[5]=1; //Cl
        valences[6]=1; //Br
        valences[7]=1; //I
        int localSize = 0;
        int sum = 0;
        for(int i=0;i<array.length;i++) {
            localSize += array[i];
            sum += (valences[i] * array[i]);
        }
        sum+=hydrogens;
        localSize+=hydrogens;
        return (sum % 2 == 0) && (sum >= 2 * (localSize - 1));
    }

    public static int[] extendArray(int[] array, int hydrogens) {
    	int[] updatedArray= new int[isotopes+1];
    	for(int i=0;i<isotopes;i++) {
    		updatedArray[i]=array[i];
    	}
    	updatedArray[isotopes]=hydrogens;
    	return updatedArray;
    }
    
    /**
     * The basic functions used in the hydrogen distributor.
     *
     * @param a the a
     * @param e the e
     * @return the new array
     */
    public static int[] addElement(int[] a, int e) {
        a = Arrays.copyOf(a, a.length + 1);
        a[a.length - 1] = e;
        return a;
    }

    public static int sum(int[] array) {
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum = sum + array[i];
        }
        return sum;
    }
    
    
    /**
     * To initialise the inputs and run the functions while recording the duration time.
     *
     * @param partition the partition
     * @param degrees the degrees
     * @return the list of int arrays
     * @throws IOException 
     */
    
    public static List<String> run() throws IOException {
        FormulaGenerator.isotopes = 8;
        List<String> result = new ArrayList<String>();
        if(verbose) System.out.println("Started generating formula for max "+heavyAtomsLimit+"...");
        for(int i=1;i<=heavyAtomsLimit;i++) { // Generating formula starting from 1 up to max number of heavy atoms.
        	FormulaGenerator.totalValue = i;
            List<int[]> list=partition(totalValue, isotopes, 0);
            for(int[] degrees: list) {
            	result=addHydrogens(degrees,result);
            }
        }
        
        /**FormulaGenerator.totalValue = heavyAtomsLimit;
        System.out.println(heavyAtomsLimit);
        List<int[]> list=partition(totalValue, isotopes, 0);
        for(int[] degrees: list) {
        	result=addHydrogens(degrees,result);
        }**/
        for(String s:result) {
    		outputFile.write(s+"\n");
        }
        outputFile.close();
        if(verbose) System.out.println("The number of generated formulae is: "+result.size());
        
        return result;
    }

    /**
     * These functions are built for the integer partitioning problem.
     *
     * @param n the n
     * @param d the d
     * @param depth the depth
     * @return the list of int arrays
     */
    public static List<int[]> partition(int n, int d, int depth) {
        if (d == depth) {
            List<int[]> array = new ArrayList<>();
            int[] take = new int[0];
            array.add(take);
            return array;
        }
        return buildArray(n, d, depth);
    }

    public static List<int[]> buildArray(int n, int d, int depth) {
        List<int[]> array = new ArrayList<>();
        IntStream range = IntStream.rangeClosed(0, n);
        for (int i : range.toArray()) {
            for (int[] item : partition(n - i, d, depth + 1)) {
            	item = addElement(item, i);
                if (item.length == d) {
                	if (sum(item) == totalValue) {
                		array.add(item);
                    }
                } else {
                	array.add(item);
                }
            }
        }
        return array;
    }
    
    /**
     * The ratio is used only in GDB 13, not for 11.
     * @param array int[]
     * @return boolean
     */
    
    public static boolean nitrogenAndOxygenRatioCheck(int[] array) {
    	boolean check=true;
    	float c=array[0];
    	float n=array[1];
    	float o=array[2];
    	float sum=(n+o);
    	if((sum/c)>1.0 || (n/c)>0.571 || (o/c)>0.666) {
    		check=false;
    	}
    	return check;
    }
    
    public static List<String> addHydrogens(int[] array, List<String> list) {
    	int[] valences= new int[8];
        valences[0]=4; //C
        valences[1]=3; //N
        valences[2]=2; //O
        valences[3]=2; //S
        valences[4]=1; //F
        valences[5]=1; //Cl
        valences[6]=1; //Br
        valences[7]=1; //I
        String formula;
        int maxHydrogen = 0;
        for(int i=0;i<array.length;i++) {
        	if(totalValue==1 || isotopes==1) {
        		maxHydrogen += ((valences[i]) * array[i]);
        	}else {
        		maxHydrogen += ((valences[i]-1) * array[i]);
        	}
        }
        for(int i=maxHydrogen;i>=0;i--) {
        	if(canBuildIsomer(array,i)) {
        		formula=buildFormula(extendArray(array,i));
        		if(RuleOfFiveDescriptor(formula)) list.add(formula);
        	}
        }
        return list;
    }
    
    public static String buildFormula(int[] array) {
    	String formula="";
    	int size= array.length;
    	String[] symbols= {"C","N","O","S","F","Cl","Br","I","H"};
    	for(int i=0;i<size-1;i++) {
    		if(array[i]>1) {
    			formula+=symbols[i]+array[i];
    		}else if(array[i]==1) {
    			formula+=symbols[i];
    		}
    	}
    	if(array[size-1]>1) {
			formula+="H"+array[size-1];
		}else if(array[size-1]==1) {
			formula+="H";
		}    	
    	return formula;
    }
    
    public void parseArgs(String[] args) throws ParseException, IOException {
        Options options = setupOptions();
        CommandLineParser parser = new DefaultParser();
        try {
            CommandLine cmd = parser.parse(options, args);
            if (cmd.hasOption("heavyAtoms")) FormulaGenerator.heavyAtomsLimit = Integer.valueOf(cmd.getOptionValue("heavyAtoms"));
            if (cmd.hasOption("path")) {
                FormulaGenerator.output = cmd.getOptionValue("path");
                new File(output).mkdirs();
                outputFile= new FileWriter(output+"/"+"formulaeMax"+heavyAtomsLimit+"HA.txt");
            }
            if (cmd.hasOption("verbose")) FormulaGenerator.verbose = true;
        } catch (ParseException e) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.setOptionComparator(null);
            String header =
                    "\nFor a given number of heavy atoms, generating molecular formulae. \n\n";
            String footer = "\nPlease report issues to the github repo.";
            formatter.printHelp("java -jar formulaGenerator.jar", header, options, footer, true);
            throw new ParseException("Problem parsing command line");
        }
    }

    public Options setupOptions() {
        Options options = new Options();
        Option ha =
                Option.builder("heavyAtoms")
                        .required(true)
                        .hasArg()
                        .longOpt("heavyAtoms")
                        .desc("Number of heavy atoms (required)")
                        .build();
        options.addOption(ha);
        Option p =
                Option.builder("path")
                        .required(true)
                        .hasArg()
                        .longOpt("outputPath")
                        .desc("output path (required)")
                        .build();
        options.addOption(p);
        Option verb =
                Option.builder("v")
                        .required(false)
                        .longOpt("verbose")
                        .desc("print message")
                        .build();
        options.addOption(verb);
        
        return options;
    }
	
    public static void main(String[] args) {
    	String[] as= {"-heavyAtoms","7","-path","C:\\Users\\mehme\\Desktop\\","-v"};
        FormulaGenerator gen = new FormulaGenerator();
        try {
            gen.parseArgs(args);
            FormulaGenerator.run();
        } catch (Exception ex) {
            if (FormulaGenerator.verbose) {
                Logger.getLogger(FormulaGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

	}
}
